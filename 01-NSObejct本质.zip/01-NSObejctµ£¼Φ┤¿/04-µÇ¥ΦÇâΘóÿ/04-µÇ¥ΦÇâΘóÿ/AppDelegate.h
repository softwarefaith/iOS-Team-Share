//
//  AppDelegate.h
//  04-思考题
//
//  Created by 蔡杰 on 2018/6/19.
//  Copyright © 2018年 AllanCai. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

